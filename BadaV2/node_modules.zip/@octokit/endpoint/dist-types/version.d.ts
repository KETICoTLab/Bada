export declare const VERSION = "6.0.12";

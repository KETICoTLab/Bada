# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.3.1](https://github.com/oclif/plugin-not-found/compare/v2.3.0...v2.3.1) (2022-01-28)


### Bug Fixes

* return command result ([8c1d2bb](https://github.com/oclif/plugin-not-found/commit/8c1d2bb3912acd95a5d65b07e62acc1f70a0905c))

## [2.3.0](https://github.com/oclif/plugin-not-found/compare/v2.2.4...v2.3.0) (2022-01-28)


### Features

* remove cli-ux ([1284f29](https://github.com/oclif/plugin-not-found/commit/1284f29c10f7445c45702cc9a18b71c4fbde5f99))

### [2.2.4](https://github.com/oclif/plugin-not-found/compare/v2.2.3...v2.2.4) (2022-01-06)


### Bug Fixes

* bump @oclif/core ([#254](https://github.com/oclif/plugin-not-found/issues/254)) ([c4f282c](https://github.com/oclif/plugin-not-found/commit/c4f282c159ba7885669c47899b9ec8da4badb350))

### [2.2.3](https://github.com/oclif/plugin-not-found/compare/v2.2.2...v2.2.3) (2021-12-08)


### Bug Fixes

* bump deps ([#237](https://github.com/oclif/plugin-not-found/issues/237)) ([4356946](https://github.com/oclif/plugin-not-found/commit/4356946e4d2db524078e9d7060061592066f9469))

### [2.2.2](https://github.com/oclif/plugin-not-found/compare/v2.2.1...v2.2.2) (2021-12-07)


### Bug Fixes

* bump deps ([#236](https://github.com/oclif/plugin-not-found/issues/236)) ([886d06d](https://github.com/oclif/plugin-not-found/commit/886d06d264aea01a151a339b9f02f6e356b5c32b))

### [2.2.1](https://github.com/oclif/plugin-not-found/compare/v2.2.0...v2.2.1) (2021-12-06)


### Bug Fixes

* bump deps ([#234](https://github.com/oclif/plugin-not-found/issues/234)) ([4a64174](https://github.com/oclif/plugin-not-found/commit/4a641746fe8f53d75fac7897cf030d57fe4aec3e))

## [2.2.0](https://github.com/oclif/plugin-not-found/compare/v2.1.4...v2.2.0) (2021-09-29)


### Features

* use oclif/core ([#208](https://github.com/oclif/plugin-not-found/issues/208)) ([7f0820f](https://github.com/oclif/plugin-not-found/commit/7f0820fc5084e6e0ea37d24e4c8ce0121f8303c3))

### [2.1.4](https://github.com/oclif/plugin-not-found/compare/v2.1.3...v2.1.4) (2021-09-22)

### [2.1.3](https://github.com/oclif/plugin-not-found/compare/v2.1.2...v2.1.3) (2021-08-26)

### [2.1.2](https://github.com/oclif/plugin-not-found/compare/v2.1.1...v2.1.2) (2021-07-15)


### Bug Fixes

* remove version suggestion ([#187](https://github.com/oclif/plugin-not-found/issues/187)) ([94a83e0](https://github.com/oclif/plugin-not-found/commit/94a83e0dadcfac1d17cfeb272fc42eac52aadfc0))

### [2.1.1](https://github.com/oclif/plugin-not-found/compare/v2.1.0...v2.1.1) (2021-07-11)


### Bug Fixes

* bump oclif/core ([90e3c7b](https://github.com/oclif/plugin-not-found/commit/90e3c7bbbca21f3f3162e3e1a666251642f8613a))

## [2.1.0](https://github.com/oclif/plugin-not-found/compare/v1.2.4...v2.1.0) (2021-07-01)


### Features

* support spaced commands ([#166](https://github.com/oclif/plugin-not-found/issues/166)) ([4222d2d](https://github.com/oclif/plugin-not-found/commit/4222d2df7d88fcc21e3ac71bfaf4cb44f317e551))


### Bug Fixes

* downgrade to node 12 ([15b9382](https://github.com/oclif/plugin-not-found/commit/15b9382bb2fc83e4246c8557f2b51dfb2ecd4f72))

## [2.0.0](https://github.com/oclif/plugin-not-found/compare/v1.2.4...v2.0.0) (2021-04-21)


### Features

* support spaced commands ([#166](https://github.com/oclif/plugin-not-found/issues/166)) ([b38be86](https://github.com/oclif/plugin-not-found/commit/b38be86fac0652b362898dc2626867af053b5883))

## [1.2.2](https://github.com/oclif/plugin-not-found/compare/v1.2.1...v1.2.2) (2018-10-13)


### Bug Fixes

* remove greenkeeper badge ([4a5c1de](https://github.com/oclif/plugin-not-found/commit/4a5c1de))

## [1.2.1](https://github.com/oclif/plugin-not-found/compare/v1.2.0...v1.2.1) (2018-10-03)


### Bug Fixes

* updated hook ([7e71672](https://github.com/oclif/plugin-not-found/commit/7e71672))

# [1.2.0](https://github.com/oclif/plugin-not-found/compare/v1.1.4...v1.2.0) (2018-08-17)


### Features

* typescript 3 ([944cac2](https://github.com/oclif/plugin-not-found/commit/944cac2))

## [1.1.4](https://github.com/oclif/plugin-not-found/compare/v1.1.3...v1.1.4) (2018-06-29)


### Bug Fixes

* bump semantic-release ([618f399](https://github.com/oclif/plugin-not-found/commit/618f399))

<a name="1.1.3"></a>
## [1.1.3](https://github.com/oclif/plugin-not-found/compare/56a4f62e911816f0a33242d458acbe446c5cf6b9...v1.1.3) (2018-06-29)


### Bug Fixes

* switch to [@oclif](https://github.com/oclif)/color ([609c4fd](https://github.com/oclif/plugin-not-found/commit/609c4fd))

<a name="1.1.2"></a>
## [1.1.2](https://github.com/oclif/plugin-not-found/compare/a67469fb44f419cb7316d4153ecdfb8ecdc08917...v1.1.2) (2018-06-15)


### Bug Fixes

* add aliases ([56a4f62](https://github.com/oclif/plugin-not-found/commit/56a4f62))

<a name="1.1.1"></a>
## [1.1.1](https://github.com/oclif/plugin-not-found/compare/7d6dd81dc1a7896a8fa07ffb8227e1f27bf967b2...v1.1.1) (2018-06-15)


### Bug Fixes

* Merge pull request [#22](https://github.com/oclif/plugin-not-found/issues/22) from oclif/levenshtein-r000ls ([a67469f](https://github.com/oclif/plugin-not-found/commit/a67469f))
* screw dice ([22de529](https://github.com/oclif/plugin-not-found/commit/22de529))

<a name="1.1.0"></a>
# [1.1.0](https://github.com/oclif/plugin-not-found/compare/df00d62218bed7c4d40a9c8e4a86cb4a29d3639a...v1.1.0) (2018-06-12)


### Features

* did you mean ([#21](https://github.com/oclif/plugin-not-found/issues/21)) ([7d6dd81](https://github.com/oclif/plugin-not-found/commit/7d6dd81))

<a name="1.0.9"></a>
## [1.0.9](https://github.com/oclif/plugin-not-found/compare/e0e49999632449d6345fa7828274a5f779140c77...v1.0.9) (2018-05-03)


### Bug Fixes

* updated command ([df00d62](https://github.com/oclif/plugin-not-found/commit/df00d62))

<a name="1.0.8"></a>
## [1.0.8](https://github.com/oclif/plugin-not-found/compare/4712f16ad98f1ac385c9bfabe4dd4652ee094215...v1.0.8) (2018-05-01)


### Bug Fixes

* updated command ([e0e4999](https://github.com/oclif/plugin-not-found/commit/e0e4999))

<a name="1.0.7"></a>
## [1.0.7](https://github.com/oclif/plugin-not-found/compare/3809b9c0d831630ab2463bd6727a1529b8c9b9e0...v1.0.7) (2018-04-24)


### Bug Fixes

* updated command ([4712f16](https://github.com/oclif/plugin-not-found/commit/4712f16))

<a name="1.0.6"></a>
## [1.0.6](https://github.com/oclif/plugin-not-found/compare/43e80a330cd3cd1c729b72b25756ab2606797efc...v1.0.6) (2018-04-18)


### Bug Fixes

* updated command ([3809b9c](https://github.com/oclif/plugin-not-found/commit/3809b9c))

<a name="1.0.5"></a>
## [1.0.5](https://github.com/oclif/plugin-not-found/compare/92b7c99bc62babd0649b3e2fa8272a25ef4783bb...v1.0.5) (2018-03-24)


### Bug Fixes

* updated command ([43e80a3](https://github.com/oclif/plugin-not-found/commit/43e80a3))

<a name="1.0.4"></a>
## [1.0.4](https://github.com/oclif/plugin-not-found/compare/cc651811728f7fe87319682bf527eb8ff7276c04...v1.0.4) (2018-03-23)


### Bug Fixes

* updated deps ([92b7c99](https://github.com/oclif/plugin-not-found/commit/92b7c99))

<a name="1.0.3"></a>
## [1.0.3](https://github.com/oclif/plugin-not-found/compare/ffb4c9437d634a7acf12a9903a6c6dedfda513ab...v1.0.3) (2018-02-28)


### Bug Fixes

* updated deps ([cc65181](https://github.com/oclif/plugin-not-found/commit/cc65181))

<a name="1.0.2"></a>
## [1.0.2](https://github.com/oclif/plugin-not-found/compare/289dcd55848ccd30ffb3a7d46df8c2300b8c73fd...v1.0.2) (2018-02-15)


### Bug Fixes

* updated command ([ffb4c94](https://github.com/oclif/plugin-not-found/commit/ffb4c94))

<a name="1.0.1"></a>
## [1.0.1](https://github.com/oclif/plugin-not-found/compare/v1.0.0...v1.0.1) (2018-02-13)


### Bug Fixes

* updated deps ([289dcd5](https://github.com/oclif/plugin-not-found/commit/289dcd5))

<a name="0.1.21"></a>
## [0.1.21](https://github.com/oclif/plugin-not-found/compare/9ddeda3adef519c3e11f0bee6678c34f4108482d...v0.1.21) (2018-02-13)


### Bug Fixes

* updated command ([43f6fe5](https://github.com/oclif/plugin-not-found/commit/43f6fe5))

<a name="0.1.20"></a>
## [0.1.20](https://github.com/anycli/plugin-not-found/compare/e87d80e567b7fa9b4353a6521fc051dcbdd24ea8...v0.1.20) (2018-02-07)


### Bug Fixes

* fixed indentation ([bb19703](https://github.com/anycli/plugin-not-found/commit/bb19703))

<a name="0.1.19"></a>
## [0.1.19](https://github.com/anycli/plugin-not-found/compare/a2871d62aff4144984b4cd86964cafe65ce2dd54...v0.1.19) (2018-02-07)


### Bug Fixes

* updated deps ([e87d80e](https://github.com/anycli/plugin-not-found/commit/e87d80e))

<a name="0.1.18"></a>
## [0.1.18](https://github.com/anycli/plugin-not-found/compare/d1ba5fb8027872305a67cdac29df6161ec8453b9...v0.1.18) (2018-02-07)


### Bug Fixes

* updated config ([a2871d6](https://github.com/anycli/plugin-not-found/commit/a2871d6))

<a name="0.1.17"></a>
## [0.1.17](https://github.com/anycli/plugin-not-found/compare/1602a582d3609d99755e160934ac2ce77df15cb9...v0.1.17) (2018-02-06)


### Bug Fixes

* updated deps ([d1ba5fb](https://github.com/anycli/plugin-not-found/commit/d1ba5fb))

<a name="0.1.16"></a>
## [0.1.16](https://github.com/anycli/plugin-not-found/compare/58f961275e5e587050b5a3bda610b2883d3a4a7f...v0.1.16) (2018-02-05)


### Bug Fixes

* remove cli-ux ([1602a58](https://github.com/anycli/plugin-not-found/commit/1602a58))

<a name="0.1.15"></a>
## [0.1.15](https://github.com/anycli/plugin-not-found/compare/621ba617c5dea977b0962641010ec5e435bbafc6...v0.1.15) (2018-02-03)


### Bug Fixes

* updated config ([e4db80b](https://github.com/anycli/plugin-not-found/commit/e4db80b))
* updated deps ([58f9612](https://github.com/anycli/plugin-not-found/commit/58f9612))

<a name="0.1.14"></a>
## [0.1.14](https://github.com/anycli/plugin-not-found/compare/9a402d89715958e43a11944367c40f80328f170b...v0.1.14) (2018-02-02)


### Bug Fixes

* bump dev-cli ([621ba61](https://github.com/anycli/plugin-not-found/commit/621ba61))

<a name="0.1.13"></a>
## [0.1.13](https://github.com/anycli/plugin-not-found/compare/e75c5c4ed78d94911d64216e2d98544dc88df7e7...v0.1.13) (2018-02-02)


### Bug Fixes

* fix manifest writing ([9a402d8](https://github.com/anycli/plugin-not-found/commit/9a402d8))

<a name="0.1.12"></a>
## [0.1.12](https://github.com/anycli/plugin-not-found/compare/f04407596efb636c2a081ef54a4d3403deece519...v0.1.12) (2018-02-02)


### Bug Fixes

* bump cache ([e75c5c4](https://github.com/anycli/plugin-not-found/commit/e75c5c4))

<a name="0.1.11"></a>
## [0.1.11](https://github.com/anycli/plugin-not-found/compare/5584f1e2da1595e39109c0c90107ef9aa8a94440...v0.1.11) (2018-02-02)


### Bug Fixes

* add plugin manifest ([f044075](https://github.com/anycli/plugin-not-found/commit/f044075))

<a name="0.1.10"></a>
## [0.1.10](https://github.com/anycli/plugin-not-found/compare/6c92b0b946510fd16cecf7d971251605cdcf41cf...v0.1.10) (2018-02-02)


### Bug Fixes

* fixed test suite ([188debd](https://github.com/anycli/plugin-not-found/commit/188debd))
* use [@heroku-cli](https://github.com/heroku-cli)/color ([5584f1e](https://github.com/anycli/plugin-not-found/commit/5584f1e))

<a name="0.1.9"></a>
## [0.1.9](https://github.com/anycli/not-found/compare/32c9ac807a8ac7ee906a164ba5f1b4f79c98a6c5...v0.1.9) (2018-02-01)


### Bug Fixes

* updated deps ([0534c32](https://github.com/anycli/not-found/commit/0534c32))

<a name="0.1.8"></a>
## [0.1.8](https://github.com/anycli/not-found/compare/5c0a7b4c93f768d46bc88bdc348352f766ec21a0...v0.1.8) (2018-02-01)


### Bug Fixes

* updated engine ([32c9ac8](https://github.com/anycli/not-found/commit/32c9ac8))

<a name="0.1.7"></a>
## [0.1.7](https://github.com/anycli/not-found/compare/3a2118d21ea80edec1d3898a813ab8d160151cc9...v0.1.7) (2018-01-31)


### Bug Fixes

* updated engine ([5c0a7b4](https://github.com/anycli/not-found/commit/5c0a7b4))

<a name="0.1.6"></a>
## [0.1.6](https://github.com/anycli/not-found/compare/11b331cca379cc564f84f8b607c7f5104689e22b...v0.1.6) (2018-01-31)


### Bug Fixes

* typescript 2.7 ([3a2118d](https://github.com/anycli/not-found/commit/3a2118d))

<a name="0.1.5"></a>
## [0.1.5](https://github.com/anycli/not-found/compare/58be5fd865b4017f733e5845b7c194c07edac617...v0.1.5) (2018-01-31)


### Bug Fixes

* skip plugin if no commands ([11b331c](https://github.com/anycli/not-found/commit/11b331c))

<a name="0.1.4"></a>
## [0.1.4](https://github.com/anycli/not-found/compare/c17b8028f0cc16188ebff803b5418006f7b2460b...v0.1.4) (2018-01-31)


### Bug Fixes

* testing release ([58be5fd](https://github.com/anycli/not-found/commit/58be5fd))

<a name="0.1.3"></a>
## [0.1.3](https://github.com/dxcli/not-found/compare/46c8668c04ed0cfd43bf5e1fe6029021ac62f0ca...v0.1.3) (2018-01-29)


### Bug Fixes

* ran generator ([04b4e5f](https://github.com/dxcli/not-found/commit/04b4e5f))

<a name="0.1.2"></a>
## [0.1.2](https://github.com/dxcli/not-found/compare/b098ed2c51567fa00fe952ca8b652ca1ba47b54c...v0.1.2) (2018-01-28)


### Bug Fixes

* ran generator ([46c8668](https://github.com/dxcli/not-found/commit/46c8668))

<a name="0.1.1"></a>
## [0.1.1](https://github.com/dxcli/not-found/compare/b406cc0ecfbf0bb9cb0c7384c1a17adc4924236a...v0.1.1) (2018-01-25)


### Bug Fixes

* updated deps ([c48e600](https://github.com/dxcli/not-found/commit/c48e600))

<a name="0.1.0"></a>
# [0.1.0](https://github.com/dxcli/not-found/compare/v0.0.0...v0.1.0) (2018-01-20)


### Features

* implemented not found hook ([b406cc0](https://github.com/dxcli/not-found/commit/b406cc0))

@oclif/plugin-not-found
========================

&#34;did you mean&#34; for oclif

[![Version](https://img.shields.io/npm/v/@oclif/plugin-not-found.svg)](https://npmjs.org/package/@oclif/plugin-not-found)
[![CircleCI](https://circleci.com/gh/oclif/plugin-not-found/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/plugin-not-found/tree/main)
[![Appveyor CI](https://ci.appveyor.com/api/projects/status/github/oclif/plugin-not-found?branch=main&svg=true)](https://ci.appveyor.com/project/heroku/plugin-not-found/branch/main)
[![Known Vulnerabilities](https://snyk.io/test/npm/@oclif/plugin-not-found/badge.svg)](https://snyk.io/test/npm/@oclif/plugin-not-found)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/plugin-not-found.svg)](https://npmjs.org/package/@oclif/plugin-not-found)
[![License](https://img.shields.io/npm/l/@oclif/plugin-not-found.svg)](https://github.com/oclif/plugin-not-found/blob/main/package.json)

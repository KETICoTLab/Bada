import { Logger } from './logger';
export declare const config: {
    errorLogger: Logger | undefined;
    debug: boolean;
    errlog: string | undefined;
};

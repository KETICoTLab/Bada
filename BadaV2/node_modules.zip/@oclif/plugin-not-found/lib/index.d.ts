import { Hook } from '@oclif/core';
declare const hook: Hook.CommandNotFound;
export default hook;

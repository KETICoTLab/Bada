export declare function omit(object: {
    [key: string]: any;
}, keysToOmit: string[]): {
    [key: string]: any;
};

export declare const VERSION = "2.17.0";

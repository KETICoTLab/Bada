declare const _default: (...scope: string[]) => (..._: any[]) => void;
export default _default;

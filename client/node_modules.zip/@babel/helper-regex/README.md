# @babel/helper-regex

> Helper function to check for literal RegEx

See our website [@babel/helper-regex](https://babeljs.io/docs/en/next/babel-helper-regex.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-regex
```

or using yarn:

```sh
yarn add @babel/helper-regex --dev
```

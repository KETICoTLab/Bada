import { Hook } from '@oclif/core';
declare const hook: Hook<'init'>;
export default hook;

import { IConfig } from '@oclif/config';
import { HelpBase, HelpOptions } from '.';
export declare function uniqBy<T>(arr: T[], fn: (cur: T) => any): T[];
export declare function compact<T>(a: (T | undefined)[]): T[];
export declare function castArray<T>(input?: T | T[]): T[];
export declare function sortBy<T>(arr: T[], fn: (i: T) => sort.Types | sort.Types[]): T[];
export declare namespace sort {
    type Types = string | number | undefined | boolean;
}
export declare function template(context: any): (t: string) => string;
interface HelpBaseDerived {
    new (config: IConfig, opts?: Partial<HelpOptions>): HelpBase;
}
export declare function getHelpClass(config: IConfig, defaultClass?: string): HelpBaseDerived;
export {};

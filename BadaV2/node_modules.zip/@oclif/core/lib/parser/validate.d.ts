import { ParserInput, ParserOutput } from '../interfaces';
export declare function validate(parse: {
    input: ParserInput;
    output: ParserOutput<any, any>;
}): void;

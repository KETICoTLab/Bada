declare const _default: (ms?: number) => Promise<unknown>;
export default _default;

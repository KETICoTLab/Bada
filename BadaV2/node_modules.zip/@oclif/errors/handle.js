module.exports = err => require('./lib/handle').handle(err)

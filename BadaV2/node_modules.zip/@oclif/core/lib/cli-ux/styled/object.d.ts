export default function styledObject(obj: any, keys?: string[]): string;

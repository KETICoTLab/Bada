# sketches-js

This is a fork of [@datadog/sketches-js](https://www.npmjs.com/package/@datadog/sketches-js) used by [Artillery](https://www.artillery.io) with a couple of fixes that haven't been upstreamed yet:

- Retain summary statistics on merge - [PR #13](https://github.com/DataDog/sketches-js/pull/13)
- Set `zeroCount` when on merge - [PR #18](https://github.com/DataDog/sketches-js/pull/18)

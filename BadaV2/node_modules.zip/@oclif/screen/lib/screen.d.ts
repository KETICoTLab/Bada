export declare let stdtermwidth: number;
export declare let errtermwidth: number;

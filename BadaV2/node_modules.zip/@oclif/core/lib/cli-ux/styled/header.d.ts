export default function styledHeader(header: string): void;

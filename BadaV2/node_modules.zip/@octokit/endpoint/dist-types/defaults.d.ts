import { EndpointDefaults } from "@octokit/types";
export declare const DEFAULTS: EndpointDefaults;

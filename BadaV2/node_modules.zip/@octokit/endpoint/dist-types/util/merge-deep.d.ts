export declare function mergeDeep(defaults: any, options: any): object;

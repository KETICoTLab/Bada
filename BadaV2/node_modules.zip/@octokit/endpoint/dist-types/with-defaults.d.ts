import { EndpointInterface, RequestParameters, EndpointDefaults } from "@octokit/types";
export declare function withDefaults(oldDefaults: EndpointDefaults | null, newDefaults: RequestParameters): EndpointInterface;

export declare type Metadata = {
    flags: {
        [key: string]: MetadataFlag;
    };
};
declare type MetadataFlag = {
    setFromDefault?: boolean;
};
export {};

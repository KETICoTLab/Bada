export declare const endpoint: import("@octokit/types").EndpointInterface<object>;

@oclif/config
==============

**This library has been replaced by [@oclif/core](https://github.com/oclif/core) and is now in maintenance mode. We will only consider PRs that address security concerns.**

base config object and standard interfaces for oclif components

[![Version](https://img.shields.io/npm/v/@oclif/config.svg)](https://npmjs.org/package/@oclif/config)
[![CircleCI](https://circleci.com/gh/oclif/config/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/config/tree/main)
[![Appveyor CI](https://ci.appveyor.com/api/projects/status/github/oclif/config?branch=main&svg=true)](https://ci.appveyor.com/project/heroku/config/branch/main)
[![Known Vulnerabilities](https://snyk.io/test/npm/@oclif/config/badge.svg)](https://snyk.io/test/npm/@oclif/config)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/config.svg)](https://npmjs.org/package/@oclif/config)
[![License](https://img.shields.io/npm/l/@oclif/config.svg)](https://github.com/oclif/config/blob/main/package.json)

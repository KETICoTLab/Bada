@oclif/help
===========

**This library has been replaced by [@oclif/core](https://github.com/oclif/core) and is now in maintenance mode. We will only consider PRs that address security concerns.**

standard help for oclif

[![Version](https://img.shields.io/npm/v/@oclif/help.svg)](https://npmjs.org/package/@oclif/help)
[![CircleCI](https://circleci.com/gh/oclif/help/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/help/tree/main)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/help.svg)](https://npmjs.org/package/@oclif/help)
[![License](https://img.shields.io/npm/l/@oclif/help.svg)](https://github.com/oclif/help/blob/main/package.json)

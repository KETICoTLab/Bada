export declare function renderList(input: (string | undefined)[][], opts: {
    maxWidth: number;
    multiline?: boolean;
    stripAnsi?: boolean;
    spacer?: string;
}): string;

export declare function extractUrlVariableNames(url: string): string[];

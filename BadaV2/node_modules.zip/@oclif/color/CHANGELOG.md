# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.0.1](https://github.com/oclif/color/compare/v1.0.0...v1.0.1) (2022-01-10)


### Bug Fixes

* bump version for release ([90535f1](https://github.com/oclif/color/commit/90535f19d8e67aea3922530e7c34503fbca8fa82))

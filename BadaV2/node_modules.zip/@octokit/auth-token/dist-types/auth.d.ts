import { Token, Authentication } from "./types";
export declare function auth(token: Token): Promise<Authentication>;

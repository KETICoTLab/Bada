export default function styledJSON(obj: any): void;
